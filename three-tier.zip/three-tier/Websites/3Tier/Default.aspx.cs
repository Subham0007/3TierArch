﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BussLogic;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        ClsBussLayer objBLL = new ClsBussLayer();
        objBLL.InsertUser(TextBox1.Text, TextBox2.Text, RadioButtonList1.SelectedItem.Text, DropDownList1.SelectedValue);
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        ClsBussLayer objBLL = new ClsBussLayer();
        GridView1.DataSource = objBLL.SelectUser();
        GridView1.DataBind();

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        TextBox1.Text = null;
        TextBox2.Text = null;
    }
}