﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAL;

namespace BLL
{
    public class Class1
    {
    }
    public class ClsBussLayer
    {
        ClsDataLayer objDAL= new ClsDataLayer();
        public void InsertUser(string _name, string _model, string _engine, string _speed)
        {
            objDAL.InsertData(_name, _model, _engine, _speed);
        }
        public object SelectUser()
        {
            return objDAL.SelectData();
        }

       
    }
}
