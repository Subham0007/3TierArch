﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
    public class Class1
    {
    }
    public class ClsDataLayer
    {
        SqlConnection con = new SqlConnection("Server=192.168.5.79;DataBase=Training;User ID=freshmind;Password=FU9l7SggmWGmsIV");
        public void InsertData(string _name, string _model, string _engine, string _speed)
        {
            SqlDataAdapter SQLAdp = new SqlDataAdapter("Insert into CAR (NAME,MODEL,ENGINE,SPEED) Values('" + _name + "','" + _model + "','" + _engine + "','" + _speed + "')", con);
            DataTable DT = new DataTable();
            SQLAdp.Fill(DT);
        }
        public object SelectData()
        {
            SqlDataAdapter SQLAdp = new SqlDataAdapter("Select * from CAR" , con);
            DataTable DT = new DataTable();
            SQLAdp.Fill(DT);
            return DT;
        }
    
    }
}
